<template>
    <footer class="app-footer">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <p class="mb-1">Taller de Base de Datos. USACH 2025/1. Grupo 1</p>
                    <a href="https://github.com/IsaacEspinoza91/Control-2-TBD-Grupo1" target="_blank"
                        rel="noopener noreferrer" class="footer-link">
                        Ver repositorio en GitHub
                    </a>
                </div>
            </div>
        </div>
    </footer>
</template>

<style scoped>
.app-footer {
    background-color: #3d4043;
    color: white;
    width: 100%;
    height: 65px;
    padding: 5px;
}

.footer-link {
    color: #6c757d;
    text-decoration: none;
    transition: color 0.3s;
}

.footer-link:hover {
    color: #f8f9fa;
    text-decoration: underline;
}
</style>