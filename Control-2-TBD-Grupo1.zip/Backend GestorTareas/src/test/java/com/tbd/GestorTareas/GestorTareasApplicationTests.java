package com.tbd.GestorTareas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorTareasApplicationTests {

	@Test
	void contextLoads() {
	}

}
